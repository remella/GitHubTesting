//
//  ViewController.m
//  geofencedemo
//
//  Created by Kevin McMahon on 9/3/12.
//  Copyright (c) 2012 Kevin McMahon. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>
#import "pARkViewController.h"

@implementation ViewController
@synthesize coordinateLabel;
@synthesize mapView;

CLLocationManager *_locationManager;
NSArray *_regionArray;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self initializeMap];
    [self initializeLocationManager];
    NSArray *geofences = [self buildGeofenceData];
    [self initializeRegionMonitoring:geofences];
    [self initializeLocationUpdates];
}

- (void)viewDidUnload
{
    [self setCoordinateLabel:nil];
    [self setMapView:nil];
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)initializeMap {
    CLLocationCoordinate2D initialCoordinate;
    initialCoordinate.latitude = 41.88072;
    initialCoordinate.longitude = -87.67429;

    [self.mapView setRegion:MKCoordinateRegionMakeWithDistance(initialCoordinate, 400, 400) animated:YES];
    self.mapView.centerCoordinate = initialCoordinate;
    [self.mapView setUserTrackingMode:MKUserTrackingModeFollow animated:YES];
}

- (void)initializeLocationManager {
    // Check to ensure location services are enabled
    if(![CLLocationManager locationServicesEnabled]) {
        [self showAlertWithMessage:@"You need to enable location services to use this app."];
        return;
    }
    
    _locationManager = [[CLLocationManager alloc] init];
    _locationManager.delegate = self;
}


- (void) initializeRegionMonitoring:(NSArray*)geofences {
    
    if (_locationManager == nil) {
        [NSException raise:@"Location Manager Not Initialized" format:@"You must initialize location manager first."];
    }
    
    if(![CLLocationManager regionMonitoringAvailable]) {
        [self showAlertWithMessage:@"This app requires region monitoring features which are unavailable on this device."];
        return;
    }
    
    for(CLRegion *geofence in geofences) {
        [_locationManager startMonitoringForRegion:geofence];
    }

}

- (NSArray*) buildGeofenceData {
    NSString* plistPath = [[NSBundle mainBundle] pathForResource:@"regions" ofType:@"plist"];
    _regionArray = [NSArray arrayWithContentsOfFile:plistPath];
    NSLog(@"_regionArray-->%@",_regionArray);
    NSMutableArray *geofences = [NSMutableArray array];
  
    ////
    for(NSDictionary *regionDict in _regionArray) {
        CLRegion *region = [self mapDictionaryToRegion:regionDict];
        NSLog(@"re >> %@",region);
        [geofences addObject:region];
        NSLog(@"geofences-->%@",geofences);

    }
    
    ///// TO store values /////
   /* NSArray *keys = [NSArray arrayWithObjects:@"latitude", @"longitude",@"radius",@"title", nil];
    NSArray *objects = [NSArray arrayWithObjects:@"1111", @"33333",@"8489",@"jrjrj", nil];
    NSDictionary *dictionary = [NSDictionary dictionaryWithObjects:objects
                                                           forKeys:keys];
    
    
    
    NSArray *keys1 = [NSArray arrayWithObjects:@"latitude", @"longitude",@"radius",@"title", nil];
    NSArray *objects1 = [NSArray arrayWithObjects:@"44444", @"-7747834",@"72737",@"hhsd", nil];
    NSDictionary *dictionary1 = [NSDictionary dictionaryWithObjects:objects1                                                           forKeys:keys1];
    
    
    NSArray * hhhhhh = [NSArray arrayWithObjects:dictionary,dictionary1, nil];
    
    for(NSDictionary *regionDict in hhhhhh) {
        CLRegion *region = [self mapDictionaryToRegion:regionDict];
        NSLog(@"re >> %@",region);
        [geofences addObject:region];
        NSLog(@"11geofences-->%@",geofences);
        
    }
    
    NSLog(@"hao hao %@",hhhhhh);*/

    return [NSArray arrayWithArray:geofences];
}

- (CLRegion*)mapDictionaryToRegion:(NSDictionary*)dictionary {
    NSString *title = [dictionary valueForKey:@"title"];
    
    CLLocationDegrees latitude = [[dictionary valueForKey:@"latitude"] doubleValue];
    CLLocationDegrees longitude =[[dictionary valueForKey:@"longitude"] doubleValue];
    CLLocationCoordinate2D centerCoordinate = CLLocationCoordinate2DMake(latitude, longitude);
        
    CLLocationDistance regionRadius = [[dictionary valueForKey:@"radius"] doubleValue];
    
    return [[CLRegion alloc] initCircularRegionWithCenter:centerCoordinate
                                                   radius:regionRadius
                                               identifier:title];
}

- (void)initializeLocationUpdates {
    [_locationManager startUpdatingLocation];
}

#pragma mark - Location Manager - Region Task Methods

- (void)locationManager:(CLLocationManager *)manager didEnterRegion:(CLRegion *)region {
    NSLog(@"Entered Region - %@", region.identifier);
    
    UIApplicationState state = [UIApplication sharedApplication].applicationState;
    BOOL result = (state == UIApplicationStateActive);
    NSLog(@"status %hhd",result);
    if (result == 0) {
        [self notificarions:@"Entering Region " fire:region.identifier];
    }else{
    [self showRegionAlert:@"Entering Region" forRegion:region.identifier];
    }
//

}

- (void)locationManager:(CLLocationManager *)manager didExitRegion:(CLRegion *)region {
    NSLog(@"Exited Region - %@", region.identifier);
//    [self showRegionAlert:@"Exiting Region" forRegion:region.identifier];
    
    UIApplicationState state = [UIApplication sharedApplication].applicationState;
    BOOL result = (state == UIApplicationStateActive);
    NSLog(@"status %hhd",result);
    if (result == 0) {
        [self notificarions:@"Exiting Region " fire:region.identifier];
    }else{
        [self showRegionAlert:@"Exiting Region" forRegion:region.identifier];
    }}

- (void)locationManager:(CLLocationManager *)manager didStartMonitoringForRegion:(CLRegion *)region {
    NSLog(@"Started monitoring %@ region", region.identifier);
}

#pragma mark - Location Manager - Standard Task Methods

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    self.coordinateLabel.text = [NSString stringWithFormat:@"%f,%f",newLocation.coordinate.latitude, newLocation.coordinate.longitude];
//    NSLog(@"coordinateLabel-- %f , log%f",newLocation.coordinate.latitude, newLocation.coordinate.longitude);
   
    
  /*  CLLocationManager *locationManager = [[CLLocationManager alloc] init];
//    if ([locationManager locationServicesEnabled])
    {
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        locationManager.distanceFilter = kCLDistanceFilterNone;
        [locationManager startUpdatingLocation];
    }
    
    
    CLLocation *location = [locationManager location];
    CLLocationCoordinate2D coordinate = [location coordinate];
    
    NSString *str=[[NSString alloc] initWithFormat:@" latitude:%f longitude:%f",coordinate.latitude,coordinate.longitude];
    NSLog(@"%@",str);*/

    
}
#pragma mark - Alert Methods

- (void) showRegionAlert:(NSString *)alertText forRegion:(NSString *)regionIdentifier {
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:alertText
                                                      message:regionIdentifier
                                                     delegate:nil
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    [message show];
}

-(void)notificarions:(NSString *)notifications fire:(NSString *)fire{
    
    NSLog(@"-->%@ -->%@",notifications,fire);
    NSString * regionn =[notifications stringByAppendingString:fire];
    
    UILocalNotification *notification = [[UILocalNotification alloc] init];
    notification.alertBody = regionn;
//    notification.alertAction = notifications;
    notification.fireDate = [[NSDate alloc] initWithTimeIntervalSinceNow:0];
    notification.timeZone = [NSTimeZone defaultTimeZone];
    notification.repeatInterval = 0;
    [[UIApplication sharedApplication] presentLocalNotificationNow:notification];
}

- (void)showAlertWithMessage:(NSString*)alertText {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Location Services Error"
                                                        message:alertText
                                                       delegate:self
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil];
    [alertView show];
}
-(IBAction)agreement:(id)sender{
    
    pARkViewController * controller = [[pARkViewController alloc]init];
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
	    controller = [[pARkViewController alloc] initWithNibName:@"pARkViewController_iPhone" bundle:nil];
	} else {
	    controller = [[pARkViewController alloc] initWithNibName:@"pARkViewController_iPad" bundle:nil];
	}
    [self presentModalViewController:controller animated:YES];

}

@end